# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .allowed_skills_claims_validator import AllowedSkillsClaimsValidator

__all__ = ["AllowedSkillsClaimsValidator"]
